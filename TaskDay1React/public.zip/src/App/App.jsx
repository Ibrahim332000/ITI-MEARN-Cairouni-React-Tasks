
import Data from "../components/Data";
// import Movies from "../components/Movies";
import "./App.css";


function App() {
  return (
    <div className="App">
      <Data></Data>
      {/* <Movies> </Movies> */}
    </div>
  );
}

export default App;
