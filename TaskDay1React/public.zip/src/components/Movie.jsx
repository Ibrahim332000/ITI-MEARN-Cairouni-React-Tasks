import HemaTybe from 'prop-types';
const styleObject = {
  backgroundColor: "blue",
  width: "60",
  margin: "5px auto",
};

const Movie = (props) => {
    const {Movieid,Moviename,Moviedur,siblings}=props; 
    return(

  <div style={styleObject}>
    <div>Movieid: {Movieid}</div>
   {Moviename&&<div>Moviename: {Moviename}</div>}
   {Moviedur&& <div>Moviedur: {Moviedur}</div>}
    <div>{siblings}</div>
  </div>
)};
Movie.propTypes={
    Movieid:HemaTybe.string.isRequired,
    Moviename:HemaTybe.string.isRequired,
    Moviedur:HemaTybe.string.isRequired,
}

export default Movie;
