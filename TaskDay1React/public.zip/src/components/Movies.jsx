import React, { useState } from "react";
import Movie from "./Movie";
import {v4 as uuid} from 'uuid';
const Movies = () => {
  const [moviesArr] = useState([
    { Movieid: uuid(), Moviename: "movie1", Moviedur: 2 },
    { Movieid: uuid(), Moviename: "movie2", Moviedur: 3 },
    { Movieid: uuid(), Moviename: "movie3", Moviedur: 3.5 },
    { Movieid: uuid(), Moviename: "movie4", Moviedur: 4 },
  ]);
  console.log(moviesArr)
  return moviesArr.map((m)=><Movie key={m.Movieid}  Movieid={m.Movieid} Moviename={m.Moviename} Moviedur={m.Moviedur}>Ibrahim Ayman to display our Movies:</Movie>);
};

export default Movies;
