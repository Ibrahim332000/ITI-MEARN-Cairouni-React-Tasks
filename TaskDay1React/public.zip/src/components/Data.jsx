import {  Component } from "react";
import axios from "axios";
class Data extends Component {
    constructor(props){
        super(props)
        console.log("constructor");
       this.state={
            task:null
        }
    }

    

componentDidMount(){
 axios.get('https://api.themoviedb.org/3/discover/movie?sort_by=popularity.desc&api_key=9813ce01a72ca1bd2ae25f091898b1c7').then(res=>this.setState({task:res.data.results}))
 
  console.log("componentDidMount");
}

componentDidUpdate(){
   console.log(this.state.task);
  console.log("componentDidUpdate")
}

  render() {
    console.log("render")
    
    
    if(!this.state.task) return <div>Loading </div>
     return this.state.task.map((m)=> <div>Task {m.id}</div>)
    //return;
    };
  }

export default Data;
